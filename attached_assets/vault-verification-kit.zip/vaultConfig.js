// vaultConfig.js
export const vaultAddress = "0x244C2D13c4Ed9153B8B6fb25499519a90771Ca4d";

import VaultABI from './abis/Vault.json';

export const vaultContract = (providerOrSigner) => new ethers.Contract(
  vaultAddress,
  VaultABI,
  providerOrSigner
);
