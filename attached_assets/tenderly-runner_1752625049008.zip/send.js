require("dotenv").config();
const { ethers } = require("ethers");
const fs = require("fs");

const RPC_URL = "https://virtual.base.rpc.tenderly.co/YOUR-ID";
const EXPLORER = "https://dashboard.tenderly.co/tx/base/";
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const TO = "0x0a7ec711da824f0C10578793ccda9298C03ec09e";

async function main() {
  const provider = new ethers.JsonRpcProvider(RPC_URL);
  const wallet = new ethers.Wallet(PRIVATE_KEY, provider);

  await provider.send("tenderly_setBalance", [[wallet.address], "0xDE0B6B3A7640000"]);

  const tx = await wallet.sendTransaction({
    to: TO,
    value: ethers.parseEther("0.01"),
  });

  const log = `Wallet: ${wallet.address}\nTX: ${tx.hash}\nLink: ${EXPLORER}${tx.hash}\n\n`;
  fs.writeFileSync("tenderly-tx-log.txt", log);
  console.log("✅ Sent 0.01 ETH");
  console.log("🔗 Explorer:", `${EXPLORER}${tx.hash}`);
}

main().catch(console.error);
