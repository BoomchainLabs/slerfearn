# 💥 Boomchain Token Deployer

Automated deployment tool for ERC-20 tokens on Base chain using Hardhat and GitHub Actions.

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Set up `.env`:
   ```
   BASE_RPC_URL=your_rpc_url
   DEPLOYER_PRIVATE_KEY=your_wallet_key
   ```

3. Compile:
   ```bash
   npx hardhat compile
   ```

4. Deploy:
   ```bash
   npm run deploy
   ```
