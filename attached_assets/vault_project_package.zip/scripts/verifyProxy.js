// Sample proxy verification script
const hre = require("hardhat");

async function main() {
    const proxyAddress = process.env.VAULT_PROXY_ADDRESS;
    console.log("Verifying proxy at:", proxyAddress);
    await hre.run("verify:verify", {
        address: proxyAddress,
        constructorArguments: [],
    });
}

main()
    .then(() => process.exit(0))
    .catch(error => {
        console.error(error);
        process.exit(1);
    });