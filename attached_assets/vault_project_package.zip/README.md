# Vault Project

## Overview
This repository contains the Vault smart contract deployment, verification scripts, CI/CD workflows, and governance documentation.

## Vault Addresses
- Vault Smart Account: 0x244C2D13c4Ed9153B8B6fb25499519a90771Ca4d
- Signer Address: 0x32fa3496B89fFD6E06c4F202480A64E0d4449A4b

## Social Media
Follow us on X: [https://x.com/slerf00](https://x.com/slerf00)

## Verification & Deployment
- Automated verification scripts included
- Proxy verification workflow configured
- CI/CD GitHub Actions for deployment and verification

## Governance
- Upgradeability governance roles and processes
- Access control linked to signer and smart account addresses