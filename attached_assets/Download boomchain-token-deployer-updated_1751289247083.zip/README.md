# Boomchain Token Deployer

This repository deploys ERC-20 compatible tokens on the Base network via GitHub Actions.

## Setup

1. Add secrets:
   - `DEPLOYER_PRIVATE_KEY`
   - `BASE_RPC_URL`

2. Run manually via GitHub → Actions → "Deploy Token to Base Mainnet".

## Files
- `deploy-token.js`: Main deployment script
- `.github/workflows/deploy-token.yml`: CI workflow
